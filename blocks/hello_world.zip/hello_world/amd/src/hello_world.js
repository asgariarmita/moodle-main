define(['core/modal_factory'], function (ModalFactory) {
    function init() {
        var button = document.getElementById('btn_helloworld');

        button.addEventListener('click', function () {
            alert('Hello world!');
        })
    };

    return {
        init: init
    }
});